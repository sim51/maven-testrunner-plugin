Selenium.version = "2.5";
Selenium.revision = ".0";

window.top.document.title += " v" + Selenium.version + Selenium.revision;

